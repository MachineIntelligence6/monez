/*
Template Name: Ubold - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Tablesaw tables init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
