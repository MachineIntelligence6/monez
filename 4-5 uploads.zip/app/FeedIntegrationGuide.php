<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeedIntegrationGuide extends Model
{
    // use HasFactory;
    protected $table = 'feeds_integration_guide';
    protected $guarded = [];

    
   
}
