<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdvertiserReportColumn extends Model
{
//    use HasFactory;
    protected $table = 'advertiser_report_columns';
    protected $guarded = [];
}
